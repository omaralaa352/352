CUDA_VISIBLE_DEVICES=0 python test.py --dataroot ./datasets/males --name males_model --which_epoch latest --display_id 0 --deploy --image_path_file males_image_list.txt --full_progression --verbose 
